# cosc381_makefileAssignment
Learn to use makefiles with simple C project
 repo: https://github.com/emu-computer-science/makefileassignment-rhayes13